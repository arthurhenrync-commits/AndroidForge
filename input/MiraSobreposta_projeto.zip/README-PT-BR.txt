MIRA SOBREPOSTA — projeto Android

O que faz:
- Desenha a mira transparente sobre outros aplicativos/jogos.
- Permite arrastar a mira, fixar/desfixar a posição, ocultar/mostrar e ajustar tamanho pelos botões + e −.
- O app pede a permissão Android "aparecer sobre outros apps".

IMPORTANTE:
- Este ZIP contém o CÓDIGO-FONTE, não um APK já compilado.
- Sobreposições podem ser bloqueadas por alguns jogos e podem violar as regras de jogos competitivos. Use apenas onde for permitido.
- Android pode restringir sobreposições em telas protegidas ou em certos jogos.
- Para criar o APK, use um computador com Android Studio/Gradle ou um serviço de build na nuvem. Nunca entregue sua senha do GitHub a sites desconhecidos.

BUILD:
1. Descompacte o ZIP.
2. Abra a pasta no Android Studio.
3. Espere a sincronização do Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK debug fica em app/build/outputs/apk/debug/app-debug.apk.

Para fazer pelo celular:
- Você pode testar um construtor de APK via GitHub Actions, como AndroidForge: https://professional-x.github.io/AndroidForge/
- Ele exige conta/token GitHub e acesso ao repositório. Revise permissões e não forneça tokens a sites não confiáveis.
