package br.com.mirasobreposta

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var size = 70
    private var opacity = 85
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF111820.toInt())
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 8)
        }
        root.addView(label("MIRA SOBREPOSTA"))
        root.addView(label("Ajuste o tamanho e a transparência antes de abrir o jogo."))
        val sizeText = label("Tamanho: $size%")
        root.addView(sizeText)
        root.addView(SeekBar(this).apply {
            max = 150; progress = size
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { size = p.coerceAtLeast(20); sizeText.text = "Tamanho: $size%" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { OverlayService.updateSettings(this@MainActivity, size, opacity) }
            })
        })
        val opacityText = label("Opacidade: $opacity%")
        root.addView(opacityText)
        root.addView(SeekBar(this).apply {
            max = 100; progress = opacity
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { opacity = p.coerceAtLeast(10); opacityText.text = "Opacidade: $opacity%" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { OverlayService.updateSettings(this@MainActivity, size, opacity) }
            })
        })
        val permission = Button(this).apply {
            text = "1. Permitir aparecer sobre outros apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permissão já concedida", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(permission)
        root.addView(Button(this).apply {
            text = "2. Iniciar mira flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Conceda a permissão primeiro.", Toast.LENGTH_LONG).show()
                } else {
                    OverlayService.updateSettings(this@MainActivity, size, opacity)
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Mira iniciada. Volte ao jogo.", Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(Button(this).apply { text = "Fechar"; setOnClickListener { finish() } })
        root.addView(label("Na faixa flutuante: arraste para posicionar; FIXAR bloqueia o movimento; MIRA oculta/mostra; × encerra."))
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
