package br.com.mirasobreposta

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var reticle: ImageView? = null
    private var locked = false
    private var shown = true
    private var sizePct = 70
    private var opacityPct = 85
    private lateinit var reticleParams: WindowManager.LayoutParams

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) createOverlay()
        return START_STICKY
    }
    private fun params(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START) =
        WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity; x = 0; y = 70 }

    private fun createOverlay() {
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        sizePct = prefs.getInt("size", 70).coerceIn(20, 220)
        opacityPct = prefs.getInt("opacity", 85).coerceIn(10, 100)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(5, 4, 5, 4)
            setBackgroundColor(0xDD111820.toInt())
        }
        fun button(text: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                this.text = text; textSize = 10f; minWidth = 0; minimumWidth = 0
                setPadding(5, 0, 5, 0); setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-2, (42*density).toInt()))
        }
        button("FIXAR") { locked = !locked; Toast.makeText(this, if (locked) "Posição fixada" else "Movimento liberado", Toast.LENGTH_SHORT).show() }
        button("MIRA") {
            shown = !shown
            reticle?.visibility = if (shown) View.VISIBLE else View.GONE
        }
        button("−") { sizePct = (sizePct - 10).coerceAtLeast(20); resizeReticle() }
        button("+") { sizePct = (sizePct + 10).coerceAtMost(220); resizeReticle() }
        button("×") { stopSelf() }
        panel = bar
        wm.addView(bar, params(-2, -2))
        reticle = ImageView(this).apply {
            setImageResource(R.drawable.reticle)
            alpha = opacityPct / 100f
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val side = (resources.displayMetrics.widthPixels * sizePct / 100).coerceAtLeast(80)
        reticleParams = params(side, side).apply {
            x = (resources.displayMetrics.widthPixels - side) / 2
            y = (resources.displayMetrics.heightPixels - side) / 2
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        wm.addView(reticle, reticleParams)
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        reticle?.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = reticleParams.x; startY = reticleParams.y; touchX = e.rawX; touchY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    if (!locked) {
                        reticleParams.x = startX + (e.rawX - touchX).toInt()
                        reticleParams.y = startY + (e.rawY - touchY).toInt()
                        try { wm.updateViewLayout(reticle, reticleParams) } catch (_: Exception) {}
                    }; true
                }
                else -> true
            }
        }
    }
    private fun resizeReticle() {
        reticle?.let {
            val side = (resources.displayMetrics.widthPixels * sizePct / 100).coerceAtLeast(80)
            reticleParams.width = side; reticleParams.height = side
            try { wm.updateViewLayout(it, reticleParams) } catch (_: Exception) {}
        }
    }
    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { reticle?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null; reticle = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun updateSettings(context: Context, size: Int, opacity: Int) {
            context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
                .putInt("size", size).putInt("opacity", opacity).apply()
        }
    }
}
